﻿using Newtonsoft.Json;
using HTTPServer;
using System.Net;
using System.Net.Http.Headers;
using System.IO;
using System.Drawing;

namespace Tester
{
    public class Program
    {
        private static string[] EndPoints = { "http://localhost:8080/Project1", "http://localhost:8080/Project2" };
        private static string localPath = @"d:\pictures\";

        private static string[] fnames = new string[] {"Sean","Mike","James","Bob","Arthur","Alexander","Dennis"};
        private static string[] lnames = new string[] { "Smith", "Johnson", "Williams", "Brown", "Johns", "Garcia", "Miller", "Davis" };

        static private CustomerRequest GetRandomCustomerRequest()
        {
            Random rand = new Random();

            CustomerRequest c = new CustomerRequest();
            c.user_id=rand.Next();
            c.name = fnames[rand.Next(fnames.Length)] +" "+ lnames[rand.Next(lnames.Length)]; 
            c.date_of_birth = rand.Next(10000).ToString()+"-"+rand.Next(13).ToString()+"-"+rand.Next(32).ToString();
            c.created_on = rand.Next(100000).ToString() + rand.Next(100000).ToString();   // Max value 9999999999 
            return c;
        }
        static private void Project1(object maxRecord)
        {
            Random rand = new Random();
            List<CustomerRequest> samples = new();
            for (int i = 0; i < rand.Next((int)maxRecord) +1; i++)
                samples.Add(GetRandomCustomerRequest());

            var json = JsonConvert.SerializeObject(samples);


            var httpWebRequest = (HttpWebRequest)WebRequest.Create(EndPoints[0]);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(json);
                streamWriter.Flush();
                streamWriter.Close();
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
                Console.WriteLine(result);  // very basic output
            }
        }
        private static async Task<object> Upload(string actionUrl)
        {
            Console.WriteLine("Executing....");

            actionUrl = EndPoints[1];

            Image newImage = Image.FromFile(@"d:\pictures\mycat2.jpg");
            ImageConverter _imageConverter = new ImageConverter();
            byte[] paramFileStream = (byte[])_imageConverter.ConvertTo(newImage, typeof(byte[]));
            Console.WriteLine("Executing3....");
            var formContent = new MultipartFormDataContent
            {
                // Send form text values here
               // {new StringContent("value1"),"key1"},
               // {new StringContent("value2"),"key2" },
                // Send Image Here
                {new StreamContent(new MemoryStream(paramFileStream)),"imagekey","filename.jpg"}
            };

            var myHttpClient = new HttpClient();
            var response = await myHttpClient.PostAsync(actionUrl.ToString(), formContent);
            string stringContent = await response.Content.ReadAsStringAsync();
            Console.WriteLine(stringContent);
            return response;
        }
 

        private static async void Project2(object picture)
        {
            Image newImage = Image.FromFile((string)picture);
            ImageConverter _imageConverter = new ImageConverter();
            byte[] paramFileStream = (byte[])_imageConverter.ConvertTo(newImage, typeof(byte[]));
            var formContent = new MultipartFormDataContent
            {
                {new StreamContent(new MemoryStream(paramFileStream)),"imagekey","filename.jpg"}
            };

            var myHttpClient = new HttpClient();
            var response = await myHttpClient.PostAsync(EndPoints[1], formContent);
            string stringContent = await response.Content.ReadAsStringAsync();
            Console.WriteLine(stringContent);
        }

        static private void Project1Tester(int maxRecord,int numOfThread)
        {
            Thread[] t = new Thread[numOfThread];
            for (int i = 0; i < t.Length; i++)
                t[i] = new Thread(new ParameterizedThreadStart(Project1));

            for (int i = 0; i < t.Length; i++)
                t[i].Start(maxRecord);
        }
        static private void Project2Tester(int numOfThread)
        {
            Random rand = new Random();
            List<string> availableFiles = new();
            foreach (string file in Directory.EnumerateFiles(localPath))
                availableFiles.Add(file);

            string[] chosenPictures = new string[numOfThread];
            Thread[] t = new Thread[numOfThread];

            for (int i = 0; i < t.Length; i++)
            {
                t[i] = new Thread(Project2);
                chosenPictures[i] = availableFiles[rand.Next(availableFiles.Count)];
            }

            for (int i = 0; i < t.Length; i++)
                t[i].Start(chosenPictures[i]);
        }


        public static void Main(string[] arg)
        {
               Project1Tester(100,20); // Maximum 100 records random generated samples, with 20 Threads to hit the API concurrently.
               Console.ReadKey();      // stopper to review the outputs
            
            //   Project2Tester(2);           // Project 2 tester
            //   Console.ReadKey();
        }
    }
}