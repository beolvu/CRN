﻿namespace HTTPServer
{
    public class Program
    {
        private static bool Running = true;
        public static void Main(string[] arg)
        {
            Console.CancelKeyPress += delegate (object sender, ConsoleCancelEventArgs e)
            {
                e.Cancel = true;
                Program.Running = false;
            };

            Console.WriteLine("Starting HTTP...");

            var httpServer = new HTTPServer(8080);

            while (Program.Running) { }

            httpServer.Stop();

            Console.WriteLine("Exiting...");
        }
    }
}