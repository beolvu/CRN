﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HTTPServer
{
    public class CustomerRequest
    {
        public int user_id { get; set; }
        public string name { get; set; }
        public string date_of_birth { get; set; }
        public string created_on { get; set; }
    }

    public class CustomerResponse
    {
        private Dictionary<int, string> map = new() { {0,"Date Format is invalid."},{1,"Monday"}, { 2, "Tuesday" }, { 3, "Wednesday" }, { 4, "Thursday" }, { 5, "Friday" }, { 6, "Saturday" }, { 7, "Sunday" } };
        public int user_id { get; set; }
        public string name { get; set; }
        public string date_of_birth { get; set; }   // The day of the week for the date_of_birth
        public string created_on { get; set; }      // The created_on as a time in the RFC 3339 string format, in EST

        public CustomerResponse(CustomerRequest req)
        {
            user_id = req.user_id;
            name = req.name;
            date_of_birth = map[FindDayOfTheWeek(req.date_of_birth)];
            created_on = ConvertUnixEpochToRFC3339Eastern(req.created_on);
        }

        private string ConvertUnixEpochToRFC3339Eastern (string timestamp)
        {
            DateTimeOffset dateTimeOffSet = DateTimeOffset.FromUnixTimeSeconds(Convert.ToInt64(timestamp));
            DateTime dateTime = TimeZoneInfo.ConvertTimeFromUtc(dateTimeOffSet.DateTime, TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"));
            return dateTime.ToString();
        }
        private int FindDayOfTheWeek(string date_of_birth)
        {
            try
            {
                string[] extract = date_of_birth.Split('-');
                int year = Convert.ToInt16(extract[0]);
                int month = Convert.ToInt16(extract[1]);
                int day = Convert.ToInt16(extract[2]);
                int[] t = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
                year -= month<3 ? 1: 0;
                return (year + year / 4 - year / 100 + year / 400 + t[month - 1] + day) % 7;
            }
            catch (Exception err)
            {
                Console.WriteLine("Birthdate format is invalid.");
            }
            return 0;            
        }
    }
}
