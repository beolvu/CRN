﻿using System.Net;
using System.Text;
using System.Reflection;
using Newtonsoft.Json;
using HttpMultipartParser;

/* ################################################################################################
 * The coding was typed in Visual Studio Community Version 
 * Used Postman to do API tests.
 * ################################################################################################ */
namespace HTTPServer
{
    public class HTTPServer
    {
        private Dictionary<string, (string type,string Response)> EndPoints;
        private string BASE;
        private HttpListener listener;
        public HTTPServer(int port)
        {
            BASE = $"http://localhost:{port}/";

            EndPoints = new() {     // Simply add more API Endpoints with it's own matching function handling method
                { $"{BASE}Project1", ("application/json", "JSONResponse")}, 
                { $"{BASE}Project2", ("multipart/form-data", "PNGResponse") }
            };
            listener = new HttpListener();
            listener.Prefixes.Add(BASE);
            listener.Start();
            Receive();
        }

        public void Stop()
        {
            listener.Stop();
        }

        public void Receive()
        {
            listener.BeginGetContext(new AsyncCallback(ListenerCallback), listener);
        }

        private void ListenerCallback(IAsyncResult result)
        {
            if (listener.IsListening)
            {
                var context = listener.EndGetContext(result);
                var request = context.Request;

                Console.WriteLine($"{request.ContentType} {request.Headers} {request.HttpMethod}");

                if (request != null && EndPoints.ContainsKey(request.Url.ToString()))
                {

                    if (request.HasEntityBody)
                    {
                        if ( request.ContentType.Contains(EndPoints[request.Url.ToString()].type) )
                        {
                            var body = request.InputStream;
                            var encoding = request.ContentEncoding;
                            MethodInfo mi = this.GetType().GetMethod(EndPoints[request.Url.ToString()].Response);
                            mi.Invoke(this, new object[] { context.Response, body, encoding });
                        }
                        else
                            GenerateResponse(context.Response,(int)HttpStatusCode.BadRequest);
                    }
                    else
                        GenerateResponse(context.Response, (int)HttpStatusCode.BadRequest);
                }
                else
                    GenerateResponse(context.Response, (int)HttpStatusCode.NotFound);

                Receive();
            }
        }
        private void GenerateResponse(HttpListenerResponse? response, int code)
        {
            if (response == null) return;
            response.StatusCode = code;
            response.ContentType = "text/plain";
            response.OutputStream.Write(new byte[] { }, 0, 0);
            response.OutputStream.Close();
        }

        /* ################################################################################################
         * Project 1. How to handle JSON format request & response
         * ################################################################################################ */
        public void JSONResponse(HttpListenerResponse? response,Stream content,Encoding encoding)
        {
            Console.WriteLine("Project1 Requested.");

            var reader = new StreamReader(content, encoding);
            string s = reader.ReadToEnd();
            var customer_reqs = JsonConvert.DeserializeObject<List<CustomerRequest>>(s);

            List<CustomerResponse> customer_reps = new();
            for (int i = 0; i < customer_reqs.Count; i++)
                customer_reps.Add(new CustomerResponse(customer_reqs[i]));

            reader.Close();
            content.Close();

            var json = JsonConvert.SerializeObject(customer_reps);
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(json.ToString());

            if (response == null) return;
            response.StatusCode = (int)HttpStatusCode.OK;
            response.ContentType = "application/json";
            response.OutputStream.Write(bytes,0,bytes.Length);
            response.OutputStream.Close();
        }

        /* ################################################################################################
         * Project 2. How to handle raster graph files and convert it
         * For the simplicity of the implementation, this function handles only one file request per each API call
         * ################################################################################################ */
        public void PNGResponse(HttpListenerResponse? response,Stream content, Encoding encoding)
        {
            Console.WriteLine("Project2 Requested.");
            var parser = MultipartFormDataParser.Parse(content); 
            var file = parser.Files.First();
            string filename = file.FileName;
            Stream data = file.Data;
          
            Console.WriteLine($"{file.FileName} , {file.Name} , {file.ContentType}");

            /* ################################################################################################
             * Commented out to catch specific targetted picture file format, will raise error if there is a non picture format
            if (file.ContentType != "image/jpeg" && file.ContentType != "text/plain")
                GenerateResponse(response, (int)HttpStatusCode.BadRequest);
            else
            */
            {
                Picture pic = new Picture(data, file.FileName);

                content.Close();
                byte[] bytes = pic.ms.ToArray();

                if (response == null) return;
                response.StatusCode = (int)HttpStatusCode.OK;
                response.ContentType = "image/png";
                response.OutputStream.Write(bytes, 0, bytes.Length);
                response.OutputStream.Close();
            }
        }
    }
}
